## Locations

1. Lisbon, Portugal 
2. Guanacaste, Costa Rica 
3. Roatan, Honduras
4. Vieques Puerto Rico
5. Curaçao
6. Roatan Honduras 
7. Vieques, PR
8. Utila, Honduras 
9. Puerto plata, Dominican Republic
10. Las Tirenas, Dominican Republic 
11. Ojochal, Costa Rica 
12. Atenas, Costa Rica 

> These are all places from House Hunter International. 

