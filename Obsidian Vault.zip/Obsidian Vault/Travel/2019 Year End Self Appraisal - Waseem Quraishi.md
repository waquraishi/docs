
# Accomplishments

## Product Owner
- Served as the product owner for the team (in addition to being the tech lead)
- This includes identifying, analyzing, prioritizing and socializing tasks with the team and external dependencies
- Worked with business resources to pull in new scope for the content service, Card-OL security fixes, as well as mobile xAPIs modifications
- Transitioned our customer facing features to the applicable feature teams for better business alignment
- Created repeatable processes and patterns used to implement the technical implementation
- Worked closely with Pushkar Damale to identify LOE for various xAPI change requests and streamline intake process

## Card Content Service
- Designed and created the architecture for the Card Content Microservice
- Cross-cutting / horizontal microservice utilized by every web card feature 
- One of the 1st MX using the new architecture
- Successfully released in 3 phases 
- Made enhancements to make the service more resilient and optimized based on production usage
- Worked with other channels (mobile) to incorporate their requirements into the content microservice
- Extensively documented all of the information related to the micro service and usage in a central repository [Content MX Design · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-design/)

## Platform Contribution
- Provided technical leadership and expertise on a variety of design, development and process improvement tasks
- Helped develop and document process to create new micro-services using the new stack (ServiceNow): [Microservice Onboarding · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/mx-onboarding/)
- Created, documented and shared steps to configure the Card-OL locally with the federated community: [Card OL Setup · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/card-ol-setup/)
- Converted Card OL from SDP to DAC
	- Documented steps and process to migrate to DAC: [DAC to SDP · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/dac-to-sdp/)
- Upgraded Tomcat 7 to 9
	- Documented, shared the steps, and provided technical support to upgrade to Tomcat 9 with the federated community: [Upgrading from Tomcat 7 to Tomcat 9 · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/upgrading-tomcat-7-to-9/)
- Fixed security violations in the Card-OL as identified by Eratocode scans
- Fixed NPI/PCI security findings in the Card-OL
- Migrating to Enterprise Sonar 
- On-boarded numerous eAPIs for the Card-OL (non-prod / prod)
- Participated in production incident calls and help identify fixes in a timely manner
- Took ownership and support for the Entitlements microservice 
- Managed JRebel licenses used by the CDS engineers on the platform 

## Mentoring / Leveling Up Team Resources
- Provided technical leadership to develop new software engineers on the team 
- Provided technical guidance to Thilaga Subramanaim, who previously was in a Dev-Op, develop in a Java engineering role 
- Assisted Hillary Hardiman get ramped up so she could immediately add value to the team
- Continued to develop Miriam Benesole into a senior developer on the team 
- Empowered team members so they can independently lead and build smaller teams within our team to deliver high value functionality 

## Mobile xAPIs
- Took over the ownership and support for 20+ existing mobile xAPIS
- On-boarded and registered 20+ xAPIs to Dev-Exchange
- Met with the business and technical contacts to create a transition roadmap
- Created repeatable process for developer on-boarding tasks for 20+ xAPIs 
	- Identified and implemented improvements to the existing xAPIs including creating Postman projects and documenting test data setup
	- [Card Rewards Redemption v6 · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/xapi-card-rewards-redemption-v6/) is an example detailing the output of a successfully on-boarded xAPI
- Created repeatable process to migrate xAPIs to our pipeline
	- Created Tracker to document all the steps and show current status 
	- [X-API AutoCruise Tracker · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/xapi-autocruise-tracker/#xapi-tracker)
- Met with business stakeholders to discuss (and implement) changes to the existing services
- Remediated Eratocode violations
- Successfully on-boarded and migrated the existing xAPIs to our Github codebase and pipeline

## Documentation
- Researched, identified and POC’d tools to easily and quickly document our technical information 
- Documented all of Perfect Circle’s technical documentation including xAPIs which is used daily by our team and others: [Content MX Design · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-design/)

# Detailed Breakdown of Accomplishments
## Content Microservice
* Designed, developed and deployed “modern” content micro-service to production
* Horizontal service utilized by every card feature on the platform
* Service can be independently deployed to production on-demand with no external dependencies
* Enhanced the service to make it more resilient and optimized
* Created extensive documentation detailing the operations and functionality of the service:  [Content MX Design · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-design/)
* Released in two major phases
	* Phase 1: Developed functionality to retrieve static content and Chariot overrides: [Content MX  Design Phase 1 · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-design/#phase-1)
	* Phase 2: Developed functionality to retrieve dynamic content from Chariot including articles, images and FAQs: [Content MX  Design Phase 2 · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-design/#phase-2)
* One of the first micro-services released into production using the new architecture
* Extended content micro-service capability to support Referrals rewards process
	* This allowed teams to target specific content and made the content retrieval process more efficient: [Content MX Specific Content · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-design/#retrieving-a-specific-content-key)
* Partnered with infrastructure teams to create DataDog and Splunk dashboards
* Successfully met deadline: [Content MX Release Timeline · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-design/#release-timeline)
* Created the Runbook containing extensive support information:  [Content MX Run Book · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-runbook/)
* Ensured the new micro-service was validated and signed off by the federated teams
* Currently working with mobile intent to include their requirements and functionality into the micro-service
* By removing the functionality from the orchestration layer, this micro-service helps achieve the goal of decomposing the monolith

### Platform Pattern Contribution
* Worked with senior engineers and platform partners to determine correct on-boarding process for new ASVs using ServiceNow
	* Helped create new process which was shared with others implementing MX’s on the platform
	* Established patterns that can be leveraged by other teams to create new micro-services
	* Created and shared our own on boarding process: [Microservice Onboarding · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/mx-onboarding/)
	
### Resiliency
* Designed the content micro-service to leverage feature toggles so in the event of a production incident, it can easily be flipped to serve content from the OL without impacting customers
* Worked with the team to make the content micro-service more resilient while optimizing for performance
* Created a monitoring dashboard which uncovered unnecessary calls
* Collaborated with impacted teams for resolution
	* Rewards platform agreed to re-architect their system so it doesn’t call for content that results in no content found errors
* Modified content micro-service to suppress the error resulting in increased  TPS and reducing the overall number of errors

### Future Growth
* Revamped content intake process and eliminated external dependencies to the Card-OL
	* Shared and achieved buy-in from the federated community:  [Content MX Flow · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-flow/)
* Continuously looking for opportunities to re-use this service across different channels
	* A recent change request to an existing xAPI may provide opportunities for the service to be consumed by mobile
	
## Card Orchestration Layer
* Provided technical leadership and expertise on a variety of design, development and process improvement tasks
* Reviewed and provided feedback on code (pull requests) developed by other teams

### SDP to DAC
* Converted Card OL from SDP to DAC
	* Using a limited set of ambiguous instructions, was able to successfully convert all the customer audit events to utilize the streaming data platform off the decommissioned digital activity collector
	* First large scale application to be converted onto the new platform
	* Received recognition from SDP team for being one of the 1st successful conversions and helping to share my documentation with other impacted teams outside of the platform: [DAC to SDP · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/dac-to-sdp/)
	* Removed redundant TCP SDP emitters as they were no longer required with the new Splunk-Kafka Connection solution
	
### Tomcat Upgrade
* Researched and upgraded the Card Orchestration Layer from Tomcat 7 to Tomcat 9
* Shared process to migrate with the federated community: [Upgrading from Tomcat 7 to Tomcat 9 · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/upgrading-tomcat-7-to-9/)
* Provided support for the teams as they ran into issues with the upgrade

### Entitlements
* Took over ownership and maintenance of the entitlements micro-service developed in Chicago
	* Heavily consumed service in the card orchestration layer
	* Ported over and updated the entitlements documentation with latest information: [Entitlements Microservice · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/entitlements-mx/)
	* Team provided technical support and assisted Grayskull with upgrades
	* Successfully transferred ownership of the service to Grayskull / DuctTape
	
### Eratacode
* Responsible for remediation of Eratocode violations in the card orchestration layer
	* Resolved multiple high and medium level security violations
	* Worked with Eratocode team to determine correct path to upgrade various libraries
	* Reached out to existing federated teams to address violations if it was specific to their feature
	
### Sonar
- Working with Grayskull team to migrate our existing Sonar server and rules to Enterprise Sonar
- Relieves our infrastructure team from managing their own Sonar instance and leverages Enterprise solution

### NPI/PCI Security Vulnerability Remediation
- Identified areas within the codebase which were flagged to contain PCI/NPI data 
- Designed orchestration layer code to filter out sensitive data in an extensible manner
	- New fields which are flagged as sensitive information can be added to an external configuration file which doesn’t need code modifications
	- Filtering removed  c1_amt, authorization, app-auth-token sensitive fields
- Released into production before the enterprise target fix date

### Support / Other
- On-boarded numerous eAPIs for the card orchestration layer for teams across the platform
- Resolved production issues as they arose 
* Requested by name based on my thought leadership and knowledge of the existing Card OL
* Addressed multiple last minute content issues (unrelated to our service) in order to ensure successful OL release
* Upgraded to later version(s) of Chassis to address security vulnerabilities

### Feature Alignment
* Worked with product and tech to determine the correct location for (our) features which were better aligned with teams delivering that specific business functionality
	* Documented and transferred ownership of the Autopay feature
		* [Autopay Instructions · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/autopay-instructions/)
	* Transferred ownership of the Edit/Cancel payment feature
	* Transferred ownership of Entitlements micro-service to Grayskull / DuctTape
	* Currently working on transferring Transaction Scrolling feature
	
## Mobile xAPIs
* Took over the code ownership of 20+ mobile xAPIs
* Migrating the mobile xAPIs into the CDS organization and pipeline
* Successfully migrated all but one service to Dev-Exchange and onto our pipeline (QA)
* Created a repeatable process used to migrate the 20+ services: [Migrating to AutoCruise· Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/xapi-to-autocruise/)
* As part of the migration effort, all the services were fully documented into a single location accessible to anyone:  [Example xAPI Documentation · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/xapi-card-activation/)
	* Will allow us and the consumers of the xAPIs to self service
	* Included enhancements such as creating Postman projects and documenting test data setup for each service
	* Single source containing all relevant and highly used information for each service
* Met with senior technical resources to determine plan of action to migrate identified services
* Provided non-prod technical support to existing xAPI service users
* Have already contributed security fixes and enhancements to the codebase
* Creating new processes to streamline the intake process and provide support activities to provide the best customer support

### Onboarding
* Onboarding includes all the activities required to understand and take ownership of the xAPIs from our mobile partners (code)
* Created a repeatable process to onboard the services
	* Using JIRA, created a process to document all the relevant information for the 20+ xAPIs including how to setup the service locally, generate test data,  document downstream API calls, set up Postman projects and links to various repositories: [Example Template · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/xapi-card-rewards-redemption-v6/)
* Identified areas of improvement (for the existing code being migrated) such as creating Postman projects for all of the services so they can be called to be validated/invoked outside of the code: [Postman · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/xapi-card-rewards-redemption-v6/#postman-collection)
* Documentation is on Github so it’s accessible by anyone who needs to understand how the services functions
* Onboarded and registered 20+ xAPIs to Dev-Exchange
* Worked with API and ISO coaches to quickly get the services reviewed and approved
* Prepared code so it can be deployed to the QA environment
* Made modifications to the code to support the ability to performance test the services
* Reviewed Sonar and Eratocode violations of the existing xAPIs so they can be shared and discussed for remediation: [xAPI Eratocode Violations· Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/xapi-eratocode-violations/)

### Migration
* Migration includes all the activities required to migrate the services to the Dev-Exchange / AutoCruise / Bogie pipeline
* Created a repeateable process to migrate the services
	* Created xAPI Tracker to provide overall view of activities and status of outstanding tasks as it related to migrating the xAPIs to our pipeline: [AutoCruise Tracker · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/xapi-autocruise-tracker/#xapi-tracker)
* Streamlined the migration process increasing the speed and reducing the risk of errors
* Commended by multiple individuals on the quality and thoroughness of the information conveyed
* Single source of truth providing high and detailed level view of required activities and current status
* On track to be in production by the end of this year / early Q1

### Support / Enhancement Activities
* Worked with the business (Pushkar Damale) to analyze intake requests and provide high level LOE
* Met with business stakeholders to discuss changes to the existing services
* Made changes to card-add-auth-user and cash-rewards-redemption to include new functionality requested by the business
* Helped to socialize and document new intake process for xAPI BAU change requests:  [xAPI Intake Request · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/xapi-autocruise-tracker/#intake-request)
* Researched and worked to resolve non-production issues related to the services
* Working on creating new process to support non-production activities such as triaging services being down and/or code issues
* Coordinating release activities amongst teams and creating timelines to promote xAPI changes to production

## Team
* Served as product owner for the Perfect Circle team
	* Since there wasn’t a dedicated business representative, engaged the role of product owner for the team
	* Met with business stakeholder(s) to determine new intent
	* Determined and defined the intent of work for the team
	* Created stories in JIRA and tagged them for various production major/minor releases
	* Documented tagging process so it can be used by others:  [Tagging Release Stories · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/tagging-release-stories/)
	* Upon completion of the story, reviewed and accepted the work
	* Reached out to various business and technical SMEs to gather additional information as it related to the development requests
	* Worked with SCRUM master to streamline various xAPI intake processes
* Leveling up Team Resources
	* Provided technical leadership to develop new software engineers on the team
		* Provided technical guidance to Thilaga Subramanaim, who previously was in a Dev-Op,  develop in a Java engineering role
			* She successfully enhanced a Java service to filter out any sensitive NPI/PCI data in the orchestration layer
			* Setup multiple xAPIs locally and prepared them for migration to our pipeline
			* Worked to address content micro-service enhancement and defects
		* Assisted Hillary Hardiman  get ramped up so she could immediately add value to the team
			* She worked to successfully upgrade the Travel Notification feature to ng7
			* Made changes to card-rewards-redemption-v6 to include additional filtering logic
			* Setup multiple xAPIs locally and prepared them for migration to our pipeline
		* Continued to develop Miriam Benesole into a senior developer on the team
			* Provided guidance to develop her Java skillset
			* Resulting in her coding a substantial amount of the content micro service
* Empowered team members so they can independently lead and build smaller teams within our team to deliver high value functionality
	* Provides opportunities for team members to become organization thought leaders in that technical space while building their own personal brand
	* Provides junior engineers with inner-team leadership and ownership opportunities as it relates to delivering “their” initiative
	* Served as an architect in that phase providing technical oversight but allowing engineers to implement code  and lightly managing other resources
	* Helped team member (associates) get reviewer and approver access for CDS projects (OL and UI)
	* Constantly challenged team members to ensure they delivered the highest quality and defect free software
* Graduated from the 2 year TLDP  program (Technology Leadership Development Program)
	* Leveraged soft skills developed in the program to successfully remediate inner team dysfunction and issues creating faster delivery while increasing overall team health and morale
	
## Documentation
* Realizing there was a lack of a consistent documentation, researched a variety of static site generators tools
	* Provides easy, consistent and accessible technical documentation to anyone in the enterprise
	* Looking for an easy, quick solution, teams can leverage to easily document their  technical information
	* Based on our needs and capabilities, initial selection included Docnado, Docusaurus and MKDocs
	* POC’d initial set but selected [Docusaurus](https://docusaurus.io/) based on our requirements, ease of use and ability to extend the project based on our changing requirements and needs
	* Presented Docusaurus POC during CDS demo day to get buy-in and increased usage from other platform teams
* Documented all of Perfect Circle’s technical documentation including xAPIs which is used daily by our team and others: [Content MX Design · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/content-mx-design/)
	* Called out my multiple teams and individuals for creating one of the best documentation sites they’ve seen in terms of detail and level of information conveyed
	* Streamlined information lookup/sharing process since all the relevant documentation is available in a single GitHub location accessible by anyone
	
## Other
* Managed JRebel licenses used by CDS engineers on the platform
* Participated in Capital One sponsored community volunteer events
* Worked  to identify and interview candidates
* Attended SpringOne 2019 conference
	* Took extensive notes which were shared amongst other engineers: [SpringOne 2019 · Perfect Circle](https://github-pages.cloud.capitalone.com/fgd274/pc-docs/docs/springone-2019.md/)

#career/2019/year-end