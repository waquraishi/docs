What we use for microservices are all back end enabled through remote [authentication](https://help.obsidian.md/Linking+notes+and+files/Internal+links).

## Section
### Further Section
https://facedragons.com/foss/obsidian-plugins/
https://help.obsidian.md/Linking+notes+and+files/Internal+links

🔥Here is the newest information that I have shared

```java
public void main(String args[]) {
  System.out.println(“Hello”)
}
```

```bash
# This is a comment
ps -ef | grep awk "Sed"
```

❤️ Here is a heart!
