Caught a few of the guys backstage at Rock the Days Festival in Florida.  

<iframe width="560" height="315" src="https://www.youtube.com/embed/LC_e6K22XXc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
