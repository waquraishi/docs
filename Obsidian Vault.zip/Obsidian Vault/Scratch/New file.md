Why is this not saving.  It was saving, just the view didn't allow me to see it. You needed to click the arrows under the file arrows. 
![[Focus.pdf]]
This is a PDF above

#tezla-pdf