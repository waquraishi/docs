This is a new file that I’m going to link [[Chevy Malibu#This is another section|linking to a section.]]

## Quote
![[Self Health.jpg]]

## Lucy

![[Lucy Binky.jpg]]