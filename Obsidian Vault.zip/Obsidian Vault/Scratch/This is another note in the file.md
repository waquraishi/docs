Writing in this tool using my phone isn’t the worst. I guess it’s equivalent to using the Bear app. I’ve never felt the creative freedom when trying to put my thoughts down using a phone. 

> Here is a fallout 


 [13400 Glendower Rd, Midlothian, VA 23113, United States](https://maps.apple.com/?address=13400%20Glendower%20Rd,%20Midlothian,%20VA%20%2023113,%20United%20States&ll=37.533607,-77.644401&q=Home&_ext=EiYp2MtbC7rDQkAxP6VgqJppU8A5VqGBZ+DEQkBBF97PDuFoU8BQAw%3D%3D&t=m)
 
