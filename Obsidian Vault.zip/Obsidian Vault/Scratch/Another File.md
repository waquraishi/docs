One of the funniest commercials is the Allstate ones with the guy from Oz.  They are so true and hilarious.  

```java
public static void main(String args[]) {
  System.out.println("Hello");
}
```

```bash
# This is a comment
ps -ef | grep awk "Sed"
```

➡ ▶ to the right 