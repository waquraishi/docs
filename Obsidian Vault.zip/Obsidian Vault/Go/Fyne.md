Fyne is used to create GUIs using Go

## Links
- [Fyne Labs](https://fynelabs.com/)
- [Fyne Labs Github](https://github.com/fynelabs)
- [Fyne Repositories](https://github.com/search?p=3&q=fyne&type=Repositorie)

